from .rustoken import *

__doc__ = rustoken.__doc__
if hasattr(rustoken, "__all__"):
    __all__ = rustoken.__all__